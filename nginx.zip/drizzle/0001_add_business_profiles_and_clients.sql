-- Migration: Add business_profiles and clients tables
-- Feature: 004-invoice-platform-ux

CREATE TABLE IF NOT EXISTS "business_profiles" (
  "id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
  "user_id" text NOT NULL UNIQUE,
  "business_name" varchar(255),
  "ntn_cnic" varchar(13),
  "province" varchar(100),
  "address" text,
  "logo_path" varchar(500),
  "fbr_token_encrypted" text,
  "fbr_token_hint" varchar(10),
  "created_at" timestamp with time zone DEFAULT now() NOT NULL,
  "updated_at" timestamp with time zone DEFAULT now() NOT NULL,
  CONSTRAINT "business_profiles_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."user"("id") ON DELETE CASCADE ON UPDATE NO ACTION
);
--> statement-breakpoint

CREATE TABLE IF NOT EXISTS "clients" (
  "id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
  "user_id" text NOT NULL,
  "business_name" varchar(255) NOT NULL,
  "ntn_cnic" varchar(13),
  "province" varchar(100),
  "address" text,
  "registration_type" varchar(50),
  "notes" text,
  "is_deleted" boolean DEFAULT false NOT NULL,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL,
  "updated_at" timestamp with time zone DEFAULT now() NOT NULL,
  CONSTRAINT "clients_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."user"("id") ON DELETE CASCADE ON UPDATE NO ACTION
);
--> statement-breakpoint

CREATE INDEX IF NOT EXISTS "clients_user_business_name_idx" ON "clients" ("user_id", "business_name");
--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "clients_user_deleted_idx" ON "clients" ("user_id", "is_deleted");
