-- Migration: Rename organizationId to userId in organization_profile table
ALTER TABLE organization_profile 
RENAME COLUMN organization_id TO user_id;
