-- P0 Security Fixes Migration
-- Fix 1: buyerRegistry column rename (organization_id → user_id) + FK
-- Fix 2: Performance indexes on tenant-scoped tables
-- Fix 3: FBR token expiry columns
-- Fix 4: Neon RLS (PERMISSIVE, no FORCE — DB owner bypasses naturally)

-- =============================================================================
-- Fix 1: buyerRegistry column rename + FK
-- =============================================================================

-- Add new column alongside old one
ALTER TABLE buyer_registry ADD COLUMN IF NOT EXISTS user_id text;

-- Copy existing data
UPDATE buyer_registry SET user_id = organization_id WHERE user_id IS NULL;

-- Make it NOT NULL
ALTER TABLE buyer_registry ALTER COLUMN user_id SET NOT NULL;

-- Add FK constraint to user table
ALTER TABLE buyer_registry ADD CONSTRAINT buyer_registry_user_id_fk
  FOREIGN KEY (user_id) REFERENCES "user"(id) ON DELETE CASCADE;

-- Drop old unique index and replace with user_id-based one
DROP INDEX IF EXISTS buyer_registry_org_ntn_idx;
CREATE UNIQUE INDEX IF NOT EXISTS buyer_registry_user_ntn_idx ON buyer_registry(user_id, ntn_cnic);

-- Drop old column
ALTER TABLE buyer_registry DROP COLUMN IF EXISTS organization_id;

-- =============================================================================
-- Fix 2: Performance indexes on tenant-scoped tables
-- =============================================================================

CREATE INDEX IF NOT EXISTS invoices_user_id_idx ON invoices(user_id);
CREATE INDEX IF NOT EXISTS invoices_user_status_idx ON invoices(user_id, status);
CREATE INDEX IF NOT EXISTS invoice_drafts_user_id_idx ON invoice_drafts(user_id);
CREATE INDEX IF NOT EXISTS hs_code_master_user_id_idx ON hs_code_master(user_id);
CREATE INDEX IF NOT EXISTS fbr_submissions_invoice_id_idx ON fbr_submissions(invoice_id);

-- =============================================================================
-- Fix 3: FBR token expiry columns
-- =============================================================================

ALTER TABLE business_profiles
  ADD COLUMN IF NOT EXISTS fbr_token_expires_at timestamptz,
  ADD COLUMN IF NOT EXISTS fbr_token_updated_at timestamptz;

-- =============================================================================
-- Fix 4: Neon RLS — PERMISSIVE policies, no FORCE (owner bypasses naturally)
-- =============================================================================

ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE line_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoice_drafts ENABLE ROW LEVEL SECURITY;
ALTER TABLE business_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE hs_code_master ENABLE ROW LEVEL SECURITY;
ALTER TABLE buyer_registry ENABLE ROW LEVEL SECURITY;

-- invoices: tenant isolation
DROP POLICY IF EXISTS tenant_isolation_invoices ON invoices;
CREATE POLICY tenant_isolation_invoices ON invoices AS PERMISSIVE FOR ALL
  USING (
    current_setting('app.current_user_id', true) IN ('', NULL::text)
    OR user_id = current_setting('app.current_user_id', true)
  );

-- line_items: inherit isolation via invoice FK (join-based; allow all so invoice-level checks apply)
DROP POLICY IF EXISTS tenant_isolation_line_items ON line_items;
CREATE POLICY tenant_isolation_line_items ON line_items AS PERMISSIVE FOR ALL
  USING (
    current_setting('app.current_user_id', true) IN ('', NULL::text)
    OR invoice_id IN (
      SELECT id FROM invoices
      WHERE user_id = current_setting('app.current_user_id', true)
    )
  );

-- invoice_drafts: tenant isolation
DROP POLICY IF EXISTS tenant_isolation_invoice_drafts ON invoice_drafts;
CREATE POLICY tenant_isolation_invoice_drafts ON invoice_drafts AS PERMISSIVE FOR ALL
  USING (
    current_setting('app.current_user_id', true) IN ('', NULL::text)
    OR user_id = current_setting('app.current_user_id', true)
  );

-- business_profiles: tenant isolation
DROP POLICY IF EXISTS tenant_isolation_business_profiles ON business_profiles;
CREATE POLICY tenant_isolation_business_profiles ON business_profiles AS PERMISSIVE FOR ALL
  USING (
    current_setting('app.current_user_id', true) IN ('', NULL::text)
    OR user_id = current_setting('app.current_user_id', true)
  );

-- hs_code_master: tenant isolation
DROP POLICY IF EXISTS tenant_isolation_hs_code_master ON hs_code_master;
CREATE POLICY tenant_isolation_hs_code_master ON hs_code_master AS PERMISSIVE FOR ALL
  USING (
    current_setting('app.current_user_id', true) IN ('', NULL::text)
    OR user_id = current_setting('app.current_user_id', true)
  );

-- buyer_registry: tenant isolation
DROP POLICY IF EXISTS tenant_isolation_buyer_registry ON buyer_registry;
CREATE POLICY tenant_isolation_buyer_registry ON buyer_registry AS PERMISSIVE FOR ALL
  USING (
    current_setting('app.current_user_id', true) IN ('', NULL::text)
    OR user_id = current_setting('app.current_user_id', true)
  );
