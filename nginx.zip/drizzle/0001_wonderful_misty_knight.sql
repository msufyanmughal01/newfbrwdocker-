CREATE TYPE "public"."fbr_environment" AS ENUM('sandbox', 'production');--> statement-breakpoint
CREATE TYPE "public"."fbr_reference_data_type" AS ENUM('provinces', 'hs_codes', 'uom', 'hs_uom', 'tax_rates', 'doc_types', 'trans_types', 'sro_schedule', 'sro_items');--> statement-breakpoint
CREATE TYPE "public"."fbr_submission_status" AS ENUM('validating', 'validated', 'submitting', 'issued', 'failed');--> statement-breakpoint
CREATE TYPE "public"."statl_status" AS ENUM('active', 'inactive', 'unknown');--> statement-breakpoint
CREATE TABLE "bulk_invoice_batches" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" text NOT NULL,
	"file_name" text NOT NULL,
	"total_rows" integer DEFAULT 0 NOT NULL,
	"valid_rows" integer DEFAULT 0 NOT NULL,
	"invalid_rows" integer DEFAULT 0 NOT NULL,
	"submitted_rows" integer DEFAULT 0 NOT NULL,
	"failed_rows" integer DEFAULT 0 NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"rows" jsonb DEFAULT '[]' NOT NULL,
	"errors" jsonb DEFAULT '[]' NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "business_profiles" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" text NOT NULL,
	"business_name" varchar(255),
	"ntn_cnic" varchar(13),
	"province" varchar(100),
	"address" text,
	"logo_path" varchar(500),
	"fbr_token_encrypted" text,
	"fbr_token_hint" varchar(10),
	"fbr_token_expires_at" timestamp with time zone,
	"fbr_token_updated_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "business_profiles_user_id_unique" UNIQUE("user_id")
);
--> statement-breakpoint
CREATE TABLE "clients" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" text NOT NULL,
	"business_name" varchar(255) NOT NULL,
	"ntn_cnic" varchar(13),
	"province" varchar(100),
	"address" text,
	"registration_type" varchar(50),
	"notes" text,
	"is_deleted" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "buyer_registry" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" text NOT NULL,
	"ntn_cnic" varchar(13) NOT NULL,
	"business_name" varchar(255) NOT NULL,
	"province" varchar(100),
	"address" text,
	"registration_type" varchar(50),
	"statl_status" "statl_status" DEFAULT 'unknown',
	"statl_status_code" varchar(10),
	"statl_checked_at" timestamp,
	"last_used_at" timestamp DEFAULT now() NOT NULL,
	"use_count" integer DEFAULT 1 NOT NULL,
	"created_at" timestamp DEFAULT now() NOT NULL,
	"updated_at" timestamp DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE "fbr_reference_cache" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"cache_key" varchar(255) NOT NULL,
	"data_type" "fbr_reference_data_type" NOT NULL,
	"payload" jsonb NOT NULL,
	"etag" varchar(255),
	"fetched_at" timestamp DEFAULT now() NOT NULL,
	"expires_at" timestamp NOT NULL,
	CONSTRAINT "fbr_reference_cache_cache_key_unique" UNIQUE("cache_key")
);
--> statement-breakpoint
CREATE TABLE "fbr_submissions" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"invoice_id" uuid NOT NULL,
	"status" "fbr_submission_status" DEFAULT 'validating' NOT NULL,
	"validate_request" jsonb,
	"validate_response" jsonb,
	"post_request" jsonb,
	"post_response" jsonb,
	"fbr_invoice_number" varchar(50),
	"fbr_error_codes" jsonb,
	"environment" "fbr_environment" DEFAULT 'sandbox' NOT NULL,
	"scenario_id" varchar(10),
	"attempted_at" timestamp DEFAULT now() NOT NULL,
	"issued_at" timestamp
);
--> statement-breakpoint
CREATE TABLE "hs_code_master" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"user_id" text NOT NULL,
	"hs_code" varchar(20) NOT NULL,
	"description" text NOT NULL,
	"uom" varchar(100),
	"is_active" boolean DEFAULT true NOT NULL,
	"sort_order" integer DEFAULT 0,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "organization_profile" DROP CONSTRAINT "organization_profile_organization_id_unique";--> statement-breakpoint
ALTER TABLE "invoice_drafts" DROP CONSTRAINT "invoice_drafts_organization_id_organization_id_fk";
--> statement-breakpoint
ALTER TABLE "invoices" DROP CONSTRAINT "invoices_organization_id_organization_id_fk";
--> statement-breakpoint
ALTER TABLE "invoices" ALTER COLUMN "status" SET DATA TYPE text;--> statement-breakpoint
ALTER TABLE "invoices" ALTER COLUMN "status" SET DEFAULT 'draft'::text;--> statement-breakpoint
DROP TYPE "public"."invoice_status";--> statement-breakpoint
CREATE TYPE "public"."invoice_status" AS ENUM('draft', 'validating', 'validated', 'submitting', 'issued', 'failed');--> statement-breakpoint
ALTER TABLE "invoices" ALTER COLUMN "status" SET DEFAULT 'draft'::"public"."invoice_status";--> statement-breakpoint
ALTER TABLE "invoices" ALTER COLUMN "status" SET DATA TYPE "public"."invoice_status" USING "status"::"public"."invoice_status";--> statement-breakpoint
ALTER TABLE "session" ADD COLUMN "active_organization_id" text;--> statement-breakpoint
ALTER TABLE "invoice_drafts" ADD COLUMN "user_id" text NOT NULL;--> statement-breakpoint
ALTER TABLE "invoices" ADD COLUMN "user_id" text NOT NULL;--> statement-breakpoint
ALTER TABLE "invoices" ADD COLUMN "fbr_submission_id" uuid;--> statement-breakpoint
ALTER TABLE "invoices" ADD COLUMN "issued_at" timestamp;--> statement-breakpoint
ALTER TABLE "organization_profile" ADD COLUMN "user_id" text NOT NULL;--> statement-breakpoint
ALTER TABLE "bulk_invoice_batches" ADD CONSTRAINT "bulk_invoice_batches_user_id_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."user"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "business_profiles" ADD CONSTRAINT "business_profiles_user_id_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."user"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "clients" ADD CONSTRAINT "clients_user_id_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."user"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "buyer_registry" ADD CONSTRAINT "buyer_registry_user_id_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."user"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "fbr_submissions" ADD CONSTRAINT "fbr_submissions_invoice_id_invoices_id_fk" FOREIGN KEY ("invoice_id") REFERENCES "public"."invoices"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "hs_code_master" ADD CONSTRAINT "hs_code_master_user_id_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."user"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "clients_user_business_name_idx" ON "clients" USING btree ("user_id","business_name");--> statement-breakpoint
CREATE INDEX "clients_user_deleted_idx" ON "clients" USING btree ("user_id","is_deleted");--> statement-breakpoint
CREATE UNIQUE INDEX "buyer_registry_user_ntn_idx" ON "buyer_registry" USING btree ("user_id","ntn_cnic");--> statement-breakpoint
CREATE INDEX "fbr_submissions_invoice_id_idx" ON "fbr_submissions" USING btree ("invoice_id");--> statement-breakpoint
CREATE INDEX "hs_code_master_user_id_idx" ON "hs_code_master" USING btree ("user_id");--> statement-breakpoint
ALTER TABLE "invoice_drafts" ADD CONSTRAINT "invoice_drafts_user_id_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."user"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "invoices" ADD CONSTRAINT "invoices_user_id_user_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."user"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX "invoices_user_id_idx" ON "invoices" USING btree ("user_id");--> statement-breakpoint
CREATE INDEX "invoices_user_status_idx" ON "invoices" USING btree ("user_id","status");--> statement-breakpoint
ALTER TABLE "invoice_drafts" DROP COLUMN "organization_id";--> statement-breakpoint
ALTER TABLE "invoices" DROP COLUMN "organization_id";--> statement-breakpoint
ALTER TABLE "organization_profile" DROP COLUMN "organization_id";--> statement-breakpoint
ALTER TABLE "organization_profile" ADD CONSTRAINT "organization_profile_user_id_unique" UNIQUE("user_id");